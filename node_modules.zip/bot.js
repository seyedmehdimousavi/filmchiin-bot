require("dotenv").config();
const { Telegraf } = require("telegraf");

const bot = new Telegraf(process.env.BOT_TOKEN);

// کانال خصوصی شما
const CHANNEL_ID = "-1002195618604";

// ---------------------------
//  دریافت پیام start
// ---------------------------
bot.start(async (ctx) => {
  try {
    const msg = ctx.message.text || "";

    // ساختار start باید مانند زیر باشد:
    // /start FILEID_xxxxxxxxxxxxx
    if (!msg.includes("FILEID_")) {
      return ctx.reply("سلام! لینک فایل معتبر نیست.");
    }

    const fileId = msg.split("FILEID_")[1].trim();
    if (!fileId) {
      return ctx.reply("file_id یافت نشد.");
    }

    await ctx.reply("در حال آماده‌سازی فایل...");

    // ارسال فیلم برای کاربر
    await ctx.telegram.sendVideo(ctx.chat.id, fileId);
  } catch (err) {
    console.error("START ERROR:", err);
    ctx.reply("خطا در ارسال فایل.");
  }
});

// ---------------------------
// هندل پیام و گرفتن chat_id کانال خصوصی
// ---------------------------
bot.on("message", async (ctx) => {
  console.log("NEW MESSAGE:", ctx.message);

  if (ctx.message.forward_from_chat) {
    console.log("PRIVATE CHANNEL CHAT ID:", ctx.message.forward_from_chat.id);
  }
});
// ---------------------------
// هندل دریافت و چاپ file_id
// ---------------------------
bot.on("video", async (ctx) => {
  const fileId = ctx.message.video.file_id;
  console.log("VIDEO FILE_ID:", fileId);

  await ctx.reply(
    "Got your video!\nfile_id:\n" + fileId,
    { parse_mode: "HTML" } // جلوگیری از خطای markdown
  );
});

// ---------------------------
// اجرای ربات
// ---------------------------
console.log("FILMCHIIN BOT IS RUNNING...");
bot.launch();
